# Deface
Here you can find index.html files which you can upload to your ~~hacked~~ websites using a shell.

## **Warning**
> This project is strictly for educational purpose

###### I will not be responsible for you indulging in any illegal things.

> Peace Out :+1:

### Here is a common HTML code you can use:-
```html
<HTML>
<HEAD>
<TITLE>You have been hacked</TITLE>
</HEAD>
<BODY bgCOLOR="000000"TEXT="WHITE">
<H1><MARQUEE>You have been hacked</H1></MARQUEE>
<PRE>

</PRE>
</BODY>
</HTML>
```
